const express = require('express');
const router = express.Router();
const BookController = require('../controllers/bookingController');

router.route('/')
            .post(BookController.createBooking)
            .get(BookController.getAllBookings)

router.route('/:id')
            .get(BookController.getBookingById)
            .put(BookController.updateBooking)
            .delete(BookController.deleteBooking)

module.exports = router;


//GET /api/bookings/user/:userId   (get all booking with user)
// GET /api/bookings/land/:landId  (get all booking with land)
// PATCH /api/bookings/:id/status  (confirm booking or change status)
//POST /api/bookings/check-availability (Checking the availability of land within a certain period)
// GET /api/bookings/stats (num total booking)


