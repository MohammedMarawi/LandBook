// app.js

// ================== Imports ==================
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bookingsRoutes = require('./routes/bookings');
const errorHandler = require('./middlewares/errorHandler');
const httpStatusText = require('../utils/httpStatusText');

require('dotenv').config();



// ================== App Initialization ==================
const app = express();



// ================== Middlewares ==================
app.use(cors());
app.use(express.json());



// ================== Routes ==================
app.use('/api/bookings', bookingsRoutes);



// ================== Database Connection ==================
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log('✅ MongoDB connected'))
  .catch((err) => {
    console.error('MongoDB connection error:', err.message);
    process.exit(1); // optional: stop the app if DB fails
  });


// ================== Global Not Found Router ==================
app.use((req, res, next) => {
  res.status(404).json({
    success: httpStatusText.ERROR,
    message: 'Route not found',
  });
});


//===============================Global Error Handler================================== 
app.use(errorHandler) ;


// ================== Server ==================
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
