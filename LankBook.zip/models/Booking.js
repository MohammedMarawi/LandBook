const mongoose = require('mongoose');

//attr booking(land-id , user-id , start-date , end-date , status , create-at , update-at,confirmed_at,confirmation_sent)
const bookingSchema = new mongoose.Schema({
  land_id: {
    //forgien key
    //populate to receive data in relationship
    type: mongoose.Schema.Types.ObjectId,
    //ref :nameModel
    ref: 'Land',
    required: true,
  },
  user_id: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  start_date: {
    type: Date,
    required: true,
  },
  end_date: {
    type: Date,
    required: true,
  },
  status: {
    type: String,
          //                         end           
    enum: ['pending', 'confirmed', 'completed', 'cancelled'],
    default: 'pending',
  },
  created_at: {
    type: Date,
    default: Date.now,
  },
  //for sort event 
  //يحتاج الى تعديل فعلي 
  updated_at: {
    type: Date,
    default: Date.now,
  },

  //not important
  //متى تم تاكيد الحجز
  confirmed_at: {
  type: Date,
  default: null
},
//منع ارسال اشعار متكرر والتحقق من الاشعارات الناقصة
confirmation_sent: {
  type: Boolean,
  default: false
}
});

module.exports = mongoose.model('Booking', bookingSchema);

//Booking convert utomatic to bookings
//to receive data in user 
//Booking.find().populate('user_id');


//confirmed_at
// if (booking.status === 'pending') {
//   booking.status = 'confirmed';
//   booking.confirmed_at = new Date();
// }

// | الحقل          | المعنى                                  |
// | -------------- | --------------------------------------- |
// | `created_at`   | متى تم إنشاء الحجز                      |
// | `confirmed_at` | متى تم تأكيد الحجز                      |
// | `updated_at`   | آخر مرة تم تعديل الحجز (قد تكون أي شيء) |


//confirmation_send
// if (booking.status === 'confirmed' && !booking.confirmation_sent) {
//   // 1. أرسل الإشعار
//   await sendEmailToUser(booking.user_id);

//   // 2. حدّث العلم
//   booking.confirmation_sent = true;
//   await booking.save();
// }
