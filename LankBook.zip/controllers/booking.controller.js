const mongoose = require('mongoose');
const Booking = require('../models/Booking');
const AppError = require('../utils/appError');
const httpStatusText = require('../utils/httpStatusText');
const catchAsync = require('../utils/catchAsync');


const createBooking = catchAsync(async (req, res, next) => {
  const { user_id, land_id, ...rest } = req.body;

  if (!user_id || !land_id) {
    return next(new AppError('user_id and land_id are required', 400, httpStatusText.FAIL));
  }

  const booking = new Booking({ user_id, land_id, ...rest });
  await booking.save();

  res.status(201).json({
    status: httpStatusText.SUCCESS,
    data: booking,
  });
});


const getAllBookings = catchAsync (async (req, res, next) => {
  
    const filter = {};
    if (req.query.user_id) filter.user_id = req.query.user_id;
    if (req.query.land_id) filter.land_id = req.query.land_id;
    if (req.query.status) filter.status = req.query.status;

    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const skip = (page - 1) * limit;

    const bookings = await Booking.find(filter)
      .skip(skip)
      .limit(limit)
      .populate('land_id user_id');

    res.status(200).json({
      status: httpStatusText.SUCCESS,
      count: bookings.length,
      data: bookings,
    });
});

const getBookingById = catchAsync ( async (req, res, next) => {

    const { id } = req.params;

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return next(new AppError('Invalid booking ID', 400, httpStatusText.FAIL));
    }

    const booking = await Booking.findById(id).populate('land_id user_id');
    if (!booking) {
      return next(new AppError('Booking not found', 404, httpStatusText.FAIL));
    }

    res.status(200).json({ status: httpStatusText.SUCCESS, data: booking });
  
});

const updateBooking = catchAsync ( async (req, res, next) => {
  
    const { id } = req.params;

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return next(new AppError('Invalid booking ID', 400, httpStatusText.FAIL));
    }

    const updated = await Booking.findByIdAndUpdate(id, req.body, {
      new: true,
      runValidators: true,
    });

    if (!updated) {
      return next(new AppError('Booking not found', 404, httpStatusText.FAIL));
    }

    res.status(200).json({ status: httpStatusText.SUCCESS, data: updated });
  
});

const deleteBooking = catchAsync ( async (req, res, next) => {
  
    const { id } = req.params;

    if (!mongoose.Types.ObjectId.isValid(id)) {
      return next(new AppError('Invalid booking ID', 400, httpStatusText.FAIL));
    }

    const deleted = await Booking.findByIdAndDelete(id);
    if (!deleted) {
      return next(new AppError('Booking not found', 404, httpStatusText.FAIL));
    }

    res.status(200).json({
      status: httpStatusText.SUCCESS,
      message: 'Booking deleted',
    });
  
});

module.exports = {
  createBooking,
  getAllBookings,
  getBookingById,
  updateBooking,
  deleteBooking,
};