const httpStatusText = require("../utils/httpStatusText");

const globalErrorHandler = (err, req, res, next) => {
  const statusCode = err.statusCode || 500;
  const statusText = err.statusText || httpStatusText.ERROR;

  res.status(statusCode).json({
    status: statusText,
    message: err.message,
    stack: process.env.NODE_ENV === "development" ? err.stack : undefined,
  });
};

module.exports = globalErrorHandler;
